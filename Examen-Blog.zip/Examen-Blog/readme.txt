Bon dia/tarde!

Faig un petit resum del funcionament del meu projecte.

	* El usuari restringit per entrar en el "Blog de voleibol" es: Mireia

	* La contrasenya es: 1234

	* Es pot entrar per la portada que est� en l'arrel: index.html

	O be directament al login: php/index.php

Atentament,

N�ria Pons